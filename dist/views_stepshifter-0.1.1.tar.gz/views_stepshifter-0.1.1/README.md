# views-stepshifter

## Installation

1. **Install** ```views_stepshifter```
```
pip install views_stepshifter
```

2. (Optional) For Mac user, lightgbm requires extra library. **Intall** ```libomp```
```
brew install libomp
```